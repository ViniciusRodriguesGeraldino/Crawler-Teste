<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/' => [[['_route' => 'homepagehome', '_controller' => 'App\\Controller\\CrawlerController::worksOnline'], null, null, null, false, false, null]],
        '/89ffb49f6c28afaac0c29af9c9d208ac/crawler' => [[['_route' => 'homepage89ffb49f6c28afaac0c29af9c9d208ac_crawler', '_controller' => 'App\\Controller\\CrawlerController::indexOnline'], null, null, null, false, false, null]],
        '/9e5317e838cb5bd8e98a013fffc2b30e/character_teste' => [[['_route' => 'homepage9e5317e838cb5bd8e98a013fffc2b30e_character_teste', '_controller' => 'App\\Controller\\CrawlerController::testeCharacter'], null, null, null, false, false, null]],
        '/9e5317e838cb5bd8e98a013fffc2b30e/character' => [[['_route' => 'homepage9e5317e838cb5bd8e98a013fffc2b30e_character', '_controller' => 'App\\Controller\\CrawlerController::indexCharacter'], null, null, null, false, false, null]],
        '/934b535800b1cba8f96a5d72f72f1611/character_death' => [[['_route' => 'homepage934b535800b1cba8f96a5d72f72f1611_character_death', '_controller' => 'App\\Controller\\CrawlerController::indexCharacterDeaths'], null, null, null, false, false, null]],
        '/b0baee9d279d34fa1dfd71aadb908c3f/playersonline' => [[['_route' => 'homepageb0baee9d279d34fa1dfd71aadb908c3f_playersonline', '_controller' => 'App\\Controller\\CrawlerController::playersOnline'], null, null, null, false, false, null]],
        '/api/ec02c59dee6faaca3189bace969c22d3/online' => [[['_route' => 'apiec02c59dee6faaca3189bace969c22d3_online', '_controller' => 'App\\Controller\\IndexController::online'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        35 => [
            [['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
